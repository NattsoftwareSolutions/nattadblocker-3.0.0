

'use strict';

/* global HTMLDocument, XMLDocument */

// For background page, auxiliary pages, and content scripts.

/******************************************************************************/

if ( self.browser instanceof Object ) {
    self.chrome = self.browser;
} else {
    self.browser = self.chrome;
}

/******************************************************************************/

// https://bugzilla.mozilla.org/show_bug.cgi?id=1408996#c9
var vAPI = window.vAPI; // jshint ignore:line



if (
    (document instanceof HTMLDocument ||
      document instanceof XMLDocument &&
      document.createElement('div') instanceof HTMLDivElement
    ) &&
    (/^image\/|^text\/plain/.test(document.contentType || '') === false)
) {
    vAPI = window.vAPI = vAPI instanceof Object && vAPI.uBO === true
        ? vAPI
        : { uBO: true };
}








/*******************************************************************************

    DO NOT:
    - Remove the following code
    - Add code beyond the following code
    Reason:
    - https://github.com/gorhill/uBlock/pull/3721
    - uBO never uses the return value from injected content scripts

**/

void 0;
