

// For background page or non-background pages

'use strict';

/******************************************************************************/
/******************************************************************************/

(function(self) {

/******************************************************************************/

vAPI.T0 = Date.now();

/******************************************************************************/

vAPI.setTimeout = vAPI.setTimeout || self.setTimeout.bind(self);

/******************************************************************************/

vAPI.webextFlavor = {
    major: 0,
    soup: new Set()
};

(function() {
    const ua = navigator.userAgent;
    const flavor = vAPI.webextFlavor;
    const soup = flavor.soup;
    const dispatch = function() {
        window.dispatchEvent(new CustomEvent('webextFlavor'));
    };

    // This is always true.
    soup.add('ublock').add('webext');

    // Whether this is a dev build.
    if ( /^\d+\.\d+\.\d+\D/.test(chrome.runtime.getManifest().version) ) {
        soup.add('devbuild');
    }

    if ( /\bMobile\b/.test(ua) ) {
        soup.add('mobile');
    }

    // Asynchronous
    if (
        self.browser instanceof Object &&
        typeof self.browser.runtime.getBrowserInfo === 'function'
    ) {
        self.browser.runtime.getBrowserInfo().then(info => {
            flavor.major = parseInt(info.version, 10) || 60;
            soup.add(info.vendor.toLowerCase())
                .add(info.name.toLowerCase());
            if ( soup.has('firefox') && flavor.major < 57 ) {
                soup.delete('html_filtering');
            }
            dispatch();
        });
        if ( self.browser.runtime.getURL('').startsWith('moz-extension://') ) {
            soup.add('mozilla')
                .add('firefox')
                .add('user_stylesheet')
                .add('html_filtering');
            flavor.major = 60;
        }
        return;
    }

    // Synchronous -- order of tests is important
    let match;
    if ( (match = /\bEdge\/(\d+)/.exec(ua)) !== null ) {
        flavor.major = parseInt(match[1], 10) || 0;
        soup.add('microsoft').add('edge');
    } else if ( (match = /\bOPR\/(\d+)/.exec(ua)) !== null ) {
        const reEx = /\bChrom(?:e|ium)\/([\d.]+)/;
        if ( reEx.test(ua) ) { match = reEx.exec(ua); }
        flavor.major = parseInt(match[1], 10) || 0;
        soup.add('opera').add('chromium');
    } else if ( (match = /\bChromium\/(\d+)/.exec(ua)) !== null ) {
        flavor.major = parseInt(match[1], 10) || 0;
        soup.add('chromium');
    } else if ( (match = /\bChrome\/(\d+)/.exec(ua)) !== null ) {
        flavor.major = parseInt(match[1], 10) || 0;
        soup.add('google').add('chromium');
    } else if ( (match = /\bSafari\/(\d+)/.exec(ua)) !== null ) {
        flavor.major = parseInt(match[1], 10) || 0;
        soup.add('apple').add('safari');
    }

  
    if ( soup.has('chromium') && flavor.major >= 66 ) {
        soup.add('user_stylesheet');
    }

    // Don't starve potential listeners
    vAPI.setTimeout(dispatch, 97);
})();

/******************************************************************************/

vAPI.download = function(details) {
    if ( !details.url ) {
        return;
    }

    var a = document.createElement('a');
    a.href = details.url;
    a.setAttribute('download', details.filename || '');
    a.setAttribute('type', 'text/plain');
    a.dispatchEvent(new MouseEvent('click'));
};

/******************************************************************************/

vAPI.getURL = chrome.runtime.getURL;

/******************************************************************************/

vAPI.i18n = chrome.i18n.getMessage;

// http://www.w3.org/International/questions/qa-scripts#directions
document.body.setAttribute(
    'dir',
    ['ar', 'he', 'fa', 'ps', 'ur'].indexOf(vAPI.i18n('@@ui_locale')) !== -1
        ? 'rtl'
        : 'ltr'
);

/******************************************************************************/



vAPI.closePopup = function() {
    if ( vAPI.webextFlavor.soup.has('firefox') ) {
        window.close();
        return;
    }


    window.open('', '_self').close();
};

/******************************************************************************/



vAPI.localStorage = {
    clear: function() {
        try {
            window.localStorage.clear();
        } catch(ex) {
        }
    },
    getItem: function(key) {
        try {
            return window.localStorage.getItem(key);
        } catch(ex) {
        }
        return null;
    },
    removeItem: function(key) {
        try {
            window.localStorage.removeItem(key);
        } catch(ex) {
        }
    },
    setItem: function(key, value) {
        try {
            window.localStorage.setItem(key, value);
        } catch(ex) {
        }
    }
};

/******************************************************************************/

})(this);

void 0;
