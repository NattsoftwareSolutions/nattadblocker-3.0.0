
'use strict';

(function() {
    let noscripts = document.querySelectorAll('noscript');
    if ( noscripts.length === 0 ) { return; }

    let redirectTimer,
        reMetaContent = /^\s*(\d+)\s*;\s*url=(['"]?)([^'"]+)\2/i,
        reSafeURL = /^https?:\/\//;

    let autoRefresh = function(root) {
        let meta = root.querySelector('meta[http-equiv="refresh"][content]');
        if ( meta === null ) { return; }
        let match = reMetaContent.exec(meta.getAttribute('content'));
        if ( match === null || match[3].trim() === '' ) { return; }
        let url = new URL(match[3], document.baseURI);
        if ( reSafeURL.test(url.href) === false ) { return; }
        redirectTimer = setTimeout(( ) => {
                location.assign(url.href);
            },
            parseInt(match[1], 10) * 1000 + 1
        );
        meta.parentNode.removeChild(meta);
    };

    let morphNoscript = function(from) {
        if ( /^application\/(?:xhtml\+)?xml/.test(document.contentType) ) {
            let to = document.createElement('span');
            while ( from.firstChild !== null ) {
                to.appendChild(from.firstChild);
            }
            return to;
        }
        let parser = new DOMParser();
        let doc = parser.parseFromString(
            '<span>' + from.textContent + '</span>',
            'text/html'
        );
        return document.adoptNode(doc.querySelector('span'));
    };

    for ( let noscript of noscripts ) {
        let parent = noscript.parentNode;
        if ( parent === null ) { continue; }
        let span = morphNoscript(noscript);
        span.style.setProperty('display', 'inline', 'important');
        if ( redirectTimer === undefined ) {
            autoRefresh(span);
        }
        parent.replaceChild(span, noscript);
    }
})();

/******************************************************************************/
