(function() {

'use strict';



var elems, i, elem, src;



elems = document.querySelectorAll('audio,video');
i = elems.length;
while ( i-- ) {
    elem = elems[i];
    if ( elem.error !== null ) {
        elem.load();
    }
}


elems = document.querySelectorAll('img');
i = elems.length;
while ( i-- ) {
    elem = elems[i];
    if ( elem.naturalWidth !== 0 && elem.naturalHeight !== 0 ) {
        continue;
    }
    if ( window.getComputedStyle(elem).getPropertyValue('display') === 'none' ) {
        continue;
    }
    src = elem.getAttribute('src');
    if ( src ) {
        elem.removeAttribute('src');
        elem.setAttribute('src', src);
    }
}


})();

void 0;
