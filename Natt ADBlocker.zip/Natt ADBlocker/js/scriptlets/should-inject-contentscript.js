

'use strict';

(function() {
    try {
        let status = vAPI.uBO !== true;
        if ( status === false && vAPI.bootstrap ) {
            self.requestIdleCallback(( ) => vAPI && vAPI.bootstrap());
        }
        return status;
    } catch(ex) {
    }
    return true;
})();
