'use strict';

/******************************************************************************/

(( ) => {
    const params = new URL(document.location).searchParams;
    const assetKey = params.get('url');
    if ( assetKey === null ) { return; }

    vAPI.messaging.send(
        'default',
        {
            what : 'getAssetContent',
            url: assetKey,
        },
        details => {
            cmEditor.setValue(details && details.content || '');
            if ( details.sourceURL ) {
                const a = document.querySelector('.cm-search-widget .sourceURL');
                a.setAttribute('href', details.sourceURL);
                a.setAttribute('title', details.sourceURL);
            }
        }
    );

    const cmEditor = new CodeMirror(
        document.getElementById('content'),
        {
            autofocus: true,
            lineNumbers: true,
            lineWrapping: true,
            readOnly: true,
            styleActiveLine: true,
        }
    );

    uBlockDashboard.patchCodeMirrorEditor(cmEditor);
})();
