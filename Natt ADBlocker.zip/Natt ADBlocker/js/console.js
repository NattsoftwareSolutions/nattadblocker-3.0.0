

'use strict';

self.log = (function() {
    const noopFunc = function() {};
    const info = function(s) { console.log(`[uBO] ${s}`); };
    return {
        get verbosity( ) { return; },
        set verbosity(level) {
            this.info = console.info = level === 'info' ? info : noopFunc;
        },
        info: noopFunc,
    };
})();
