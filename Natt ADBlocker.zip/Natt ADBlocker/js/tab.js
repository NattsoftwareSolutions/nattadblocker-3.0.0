

'use strict';

/******************************************************************************/
/******************************************************************************/


µBlock.normalizePageURL = function(tabId, pageURL) {
    if ( tabId < 0 ) {
        return 'http://behind-the-scene/';
    }
    const uri = this.URI.set(pageURL);
    const scheme = uri.scheme;
    if ( scheme === 'https' || scheme === 'http' ) {
        return uri.normalizedURI();
    }

    let fakeHostname = scheme + '-scheme';

    if ( uri.hostname !== '' ) {
        fakeHostname = uri.hostname + '.' + fakeHostname;
    } else if ( scheme === 'about' && uri.path !== '' ) {
        fakeHostname = uri.path + '.' + fakeHostname;
    }

    return `http://${fakeHostname}/`;
};

/******************************************************************************/


µBlock.tabContextManager = (( ) => {
    const µb = µBlock;
    const tabContexts = new Map();

    
    let mostRecentRootDocURL = '';
    let mostRecentRootDocURLTimestamp = 0;

    const popupCandidates = new Map();

    const PopupCandidate = class {
        constructor(targetTabId, openerTabId) {
            this.targetTabId = targetTabId;
            this.opener = {
                tabId: openerTabId,
                popunder: false,
                trustedURL: openerTabId === µb.mouseEventRegister.tabId
                    ? µb.mouseEventRegister.url
                    : ''
            };
            this.selfDestructionTimer = null;
            this.launchSelfDestruction();
        }

        destroy() {
            if ( this.selfDestructionTimer !== null ) {
                clearTimeout(this.selfDestructionTimer);
            }
            popupCandidates.delete(this.targetTabId);
        }

        launchSelfDestruction() {
            if ( this.selfDestructionTimer !== null ) {
                clearTimeout(this.selfDestructionTimer);
            }
            this.selfDestructionTimer = vAPI.setTimeout(
                ( ) => this.destroy(),
                10000
            );
        }
    };

    const popupCandidateTest = function(targetTabId) {
        for ( const entry of popupCandidates ) {
            const tabId = entry[0];
            const candidate = entry[1];
            if (
                targetTabId !== tabId &&
                targetTabId !== candidate.opener.tabId
            ) {
                continue;
            }

            if ( targetTabId === candidate.opener.tabId ) {
                candidate.opener.popunder = true;
            }
            if ( vAPI.tabs.onPopupUpdated(tabId, candidate.opener) === true ) {
                candidate.destroy();
            } else {
                candidate.launchSelfDestruction();
            }
        }
    };

    vAPI.tabs.onPopupCreated = function(targetTabId, openerTabId) {
        const popup = popupCandidates.get(targetTabId);
        if ( popup === undefined ) {
            popupCandidates.set(
                targetTabId,
                new PopupCandidate(targetTabId, openerTabId)
            );
        }
        popupCandidateTest(targetTabId);
    };

    const gcPeriod = 10 * 60 * 1000;

    // A pushed entry is removed from the stack unless it is committed with
    // a set time.
    const StackEntry = function(url, commit) {
        this.url = url;
        this.committed = commit;
        this.tstamp = Date.now();
    };

    const TabContext = function(tabId) {
        this.tabId = tabId;
        this.stack = [];
        this.rawURL =
        this.normalURL =
        this.origin =
        this.rootHostname =
        this.rootDomain = '';
        this.commitTimer = null;
        this.gcTimer = null;
        this.onGCBarrier = false;
        this.netFiltering = true;
        this.netFilteringReadTime = 0;

        tabContexts.set(tabId, this);
    };

    TabContext.prototype.destroy = function() {
        if ( vAPI.isBehindTheSceneTabId(this.tabId) ) { return; }
        if ( this.gcTimer !== null ) {
            clearTimeout(this.gcTimer);
            this.gcTimer = null;
        }
        tabContexts.delete(this.tabId);
    };

    TabContext.prototype.onTab = function(tab) {
        if ( tab ) {
            this.gcTimer = vAPI.setTimeout(( ) => this.onGC(), gcPeriod);
        } else {
            this.destroy();
        }
    };

    TabContext.prototype.onGC = function() {
        if ( vAPI.isBehindTheSceneTabId(this.tabId) ) { return; }

        if ( this.onGCBarrier ) {
            return;
        }
        this.onGCBarrier = true;
        this.gcTimer = null;
        vAPI.tabs.get(this.tabId, tab => { this.onTab(tab); });
        this.onGCBarrier = false;
    };


    TabContext.prototype.onCommit = function() {
        if ( vAPI.isBehindTheSceneTabId(this.tabId) ) {
            return;
        }
        this.commitTimer = null;
        // Remove uncommitted entries at the top of the stack.
        let i = this.stack.length;
        while ( i-- ) {
            if ( this.stack[i].committed ) { break; }
        }

        if ( i === -1 && this.stack.length !== 0 ) {
            this.stack[0].committed = true;
            i = 0;
        }
        i += 1;
        if ( i < this.stack.length ) {
            this.stack.length = i;
            this.update();
        }
    };

    // This takes care of orphanized tab contexts. Can't be started for all
    // contexts, as the behind-the-scene context is permanent -- so we do not
    // want to flush it.
    TabContext.prototype.autodestroy = function() {
        if ( vAPI.isBehindTheSceneTabId(this.tabId) ) { return; }
        this.gcTimer = vAPI.setTimeout(( ) => this.onGC(), gcPeriod);
    };

    // Update just force all properties to be updated to match the most recent
    // root URL.
    TabContext.prototype.update = function() {
        this.netFilteringReadTime = 0;
        if ( this.stack.length === 0 ) {
            this.rawURL =
            this.normalURL =
            this.origin =
            this.rootHostname =
            this.rootDomain = '';
            return;
        }
        const stackEntry = this.stack[this.stack.length - 1];
        this.rawURL = stackEntry.url;
        this.normalURL = µb.normalizePageURL(this.tabId, this.rawURL);
        this.origin = µb.URI.originFromURI(this.normalURL);
        this.rootHostname = µb.URI.hostnameFromURI(this.origin);
        this.rootDomain =
            µb.URI.domainFromHostname(this.rootHostname) ||
            this.rootHostname;
    };

    // Called whenever a candidate root URL is spotted for the tab.
    TabContext.prototype.push = function(url) {
        if ( vAPI.isBehindTheSceneTabId(this.tabId) ) {
            return;
        }
        const count = this.stack.length;
        if ( count !== 0 && this.stack[count - 1].url === url ) {
            return;
        }
        this.stack.push(new StackEntry(url));
        this.update();
        popupCandidateTest(this.tabId);
        if ( this.commitTimer !== null ) {
            clearTimeout(this.commitTimer);
        }
        this.commitTimer = vAPI.setTimeout(( ) => this.onCommit(), 500);
    };

    // This tells that the url is definitely the one to be associated with the
    // tab, there is no longer any ambiguity about which root URL is really
    // sitting in which tab.
    TabContext.prototype.commit = function(url) {
        if ( vAPI.isBehindTheSceneTabId(this.tabId) ) { return; }
        if ( this.stack.length !== 0 ) {
            const top = this.stack[this.stack.length - 1];
            if ( top.url === url && top.committed ) { return false; }
        }
        this.stack = [new StackEntry(url, true)];
        this.update();
        return true;
    };

    TabContext.prototype.getNetFilteringSwitch = function() {
        if ( this.netFilteringReadTime > µb.netWhitelistModifyTime ) {
            return this.netFiltering;
        }

        this.netFiltering = µb.getNetFilteringSwitch(this.normalURL);
        if (
            this.netFiltering &&
            this.rawURL !== this.normalURL &&
            this.rawURL !== ''
        ) {
            this.netFiltering = µb.getNetFilteringSwitch(this.rawURL);
        }
        this.netFilteringReadTime = Date.now();
        return this.netFiltering;
    };

    // These are to be used for the API of the tab context manager.

    const push = function(tabId, url) {
        let entry = tabContexts.get(tabId);
        if ( entry === undefined ) {
            entry = new TabContext(tabId);
            entry.autodestroy();
        }
        entry.push(url);
        mostRecentRootDocURL = url;
        mostRecentRootDocURLTimestamp = Date.now();
        return entry;
    };

    // Find a tab context for a specific tab.
    const lookup = function(tabId) {
        return tabContexts.get(tabId) || null;
    };

    // Find a tab context for a specific tab. If none is found, attempt to
    // fix this. When all fail, the behind-the-scene context is returned.
    const mustLookup = function(tabId) {
        const entry = tabContexts.get(tabId);
        if ( entry !== undefined ) {
            return entry;
        }

        if (
            mostRecentRootDocURL !== '' &&
            mostRecentRootDocURLTimestamp + 500 < Date.now()
        ) {
            mostRecentRootDocURL = '';
        }
       
        if ( mostRecentRootDocURL !== '' ) {
            return push(tabId, mostRecentRootDocURL);
        }
       
        return tabContexts.get(vAPI.noTabId);
    };

    const commit = function(tabId, url) {
        let entry = tabContexts.get(tabId);
        if ( entry === undefined ) {
            entry = push(tabId, url);
        } else if ( entry.commit(url) ) {
            popupCandidateTest(tabId);
        }
        return entry;
    };

    const exists = function(tabId) {
        return tabContexts.get(tabId) !== undefined;
    };

    // Behind-the-scene tab context
    {
        const entry = new TabContext(vAPI.noTabId);
        entry.stack.push(new StackEntry('', true));
        entry.rawURL = '';
        entry.normalURL = µb.normalizePageURL(entry.tabId);
        entry.origin = µb.URI.originFromURI(entry.normalURL);
        entry.rootHostname = µb.URI.hostnameFromURI(entry.origin);
        entry.rootDomain = µb.URI.domainFromHostname(entry.rootHostname);
    }

    // Context object, typically to be used to feed filtering engines.
    const contextJunkyard = [];
    const Context = class {
        constructor(tabId) {
            this.init(tabId);
        }
        init(tabId) {
            const tabContext = lookup(tabId);
            this.rootHostname = tabContext.rootHostname;
            this.rootDomain = tabContext.rootDomain;
            this.pageHostname =
            this.pageDomain =
            this.requestURL =
            this.origin =
            this.requestHostname =
            this.requestDomain = '';
            return this;
        }
        dispose() {
            contextJunkyard.push(this);
        }
    };

    const createContext = function(tabId) {
        if ( contextJunkyard.length ) {
            return contextJunkyard.pop().init(tabId);
        }
        return new Context(tabId);
    };

    return {
        push: push,
        commit: commit,
        lookup: lookup,
        mustLookup: mustLookup,
        exists: exists,
        createContext: createContext
    };
})();

/******************************************************************************/
/******************************************************************************/

// When the DOM content of root frame is loaded, this means the tab
// content has changed.

vAPI.tabs.onNavigation = function(details) {
    const µb = µBlock;
    if ( details.frameId === 0 ) {
        µb.tabContextManager.commit(details.tabId, details.url);
        let pageStore = µb.bindTabToPageStats(details.tabId, 'tabCommitted');
        if ( pageStore ) {
            pageStore.journalAddRootFrame('committed', details.url);
        }
    }
    if ( µb.canInjectScriptletsNow ) {
        let pageStore = µb.pageStoreFromTabId(details.tabId);
        if ( pageStore !== null && pageStore.getNetFilteringSwitch() ) {
            µb.scriptletFilteringEngine.injectNow(details);
        }
    }
};

/******************************************************************************/

// It may happen the URL in the tab changes, while the page's document
// stays the same (for instance, Google Maps). Without this listener,
// the extension icon won't be properly refreshed.

vAPI.tabs.onUpdated = function(tabId, changeInfo, tab) {
    if ( !tab.url || tab.url === '' ) { return; }
    if ( !changeInfo.url ) { return; }
    µBlock.tabContextManager.commit(tabId, changeInfo.url);
    µBlock.bindTabToPageStats(tabId, 'tabUpdated');
};

/******************************************************************************/

vAPI.tabs.onClosed = function(tabId) {
    if (  vAPI.isBehindTheSceneTabId(tabId) ) { return; }
    µBlock.unbindTabFromPageStats(tabId);
    µBlock.contextMenu.update();
};

/******************************************************************************/



vAPI.tabs.onPopupUpdated = (( ) => {
    const µb = µBlock;
    
    const fctxt = µBlock.filteringContext.setFilter(undefined);

   
    const areDifferentURLs = function(a, b) {
        if ( b === '' ) { return true; }
        if ( b.startsWith('about:') ) { return false; }
        let pos = a.indexOf('://');
        if ( pos === -1 ) { return false; }
        a = a.slice(pos);
        pos = b.indexOf('://');
        if ( pos !== -1 ) {
            b = b.slice(pos);
        }
        return b !== a;
    };

    const popupMatch = function(openerURL, targetURL, popupType) {
        fctxt.setTabOriginFromURL(openerURL)
             .setDocOriginFromURL(openerURL)
             .setURL(targetURL)
             .setType('popup');
        let result;

        

       
        if ( fctxt.getTabHostname() !== '' && targetURL !== 'about:blank' ) {
            
            if (
                popupType === 'popup' &&
                µb.sessionSwitches.evaluateZ(
                    'no-popups',
                    fctxt.getTabHostname()
                )
            ) {
                fctxt.filter = {
                    raw: 'no-popups: ' + µb.sessionSwitches.z + ' true',
                    result: 1,
                    source: 'switch'
                };
                return 1;
            }

          
            result = µb.sessionURLFiltering.evaluateZ(
                fctxt.getTabHostname(),
                targetURL,
                popupType
            );
            if (
                result === 1 && µb.sessionURLFiltering.type === popupType ||
                result === 2
            ) {
                fctxt.filter = µb.sessionURLFiltering.toLogData();
                return result;
            }

            
            result = µb.sessionFirewall.evaluateCellZY(
                fctxt.getTabHostname(),
                fctxt.getHostname(),
                popupType
            );
            if ( result === 2 ) {
                fctxt.filter = µb.sessionFirewall.toLogData();
                return 2;
            }
        }

       
        if ( µb.getNetFilteringSwitch(targetURL) ) {
            fctxt.type = popupType;
            result = µb.staticNetFilteringEngine.matchString(fctxt, 0b0001);
            if ( result !== 0 ) {
                fctxt.filter = µb.staticNetFilteringEngine.toLogData();
                return result;
            }
        }

        return 0;
    };

    const mapPopunderResult = function(popunderURL, popunderHostname, result) {
        if (
            fctxt.filter === undefined ||
            fctxt.filter !== 'static' ||
            fctxt.filter.token === µb.staticNetFilteringEngine.noTokenHash
        ) {
            return 0;
        }
        if ( fctxt.filter.token === µb.staticNetFilteringEngine.dotTokenHash ) {
            return result;
        }
        const re = new RegExp(fctxt.filter.regex, 'i');
        const matches = re.exec(popunderURL);
        if ( matches === null ) { return 0; }
        const beg = matches.index;
        const end = beg + matches[0].length;
        const pos = popunderURL.indexOf(popunderHostname);
        if ( pos === -1 ) { return 0; }
      
        return beg >= pos && beg < pos + popunderHostname.length && end > pos
            ? result
            : 0;
    };

    const popunderMatch = function(openerURL, targetURL) {
        let result = popupMatch(targetURL, openerURL, 'popunder');
        if ( result === 1 ) { return result; }

        let popunderURL = openerURL,
            popunderHostname = µb.URI.hostnameFromURI(popunderURL);
        if ( popunderHostname === '' ) { return 0; }

        result = mapPopunderResult(
            popunderURL,
            popunderHostname,
            popupMatch(targetURL, popunderURL, 'popup')
        );
        if ( result !== 0 ) { return result; }

        popunderURL = µb.URI.originFromURI(popunderURL);
        if ( popunderURL === '' ) { return 0; }

        return mapPopunderResult(
            popunderURL,
            popunderHostname,
            popupMatch(targetURL, popunderURL, 'popup')
        );
    };

    return function(targetTabId, openerDetails) {
        // Opener details.
        const openerTabId = openerDetails.tabId;
        let tabContext = µb.tabContextManager.lookup(openerTabId);
        if ( tabContext === null ) { return; }
        const openerURL = tabContext.rawURL;
        if ( openerURL === '' ) { return; }

        // Popup details.
        tabContext = µb.tabContextManager.lookup(targetTabId);
        if ( tabContext === null ) { return; }
        let targetURL = tabContext.rawURL;
        if ( targetURL === '' ) { return; }


        if ( µb.getNetFilteringSwitch(openerURL) === false ) { return; }

    
        if (
            µb.getNetFilteringSwitch(µb.normalizePageURL(
                openerTabId,
                openerURL)
            ) === false
        ) {
            return;
        }

        // If the page URL is that of our "blocked page" URL, extract the URL of
        // the page which was blocked.
        if ( targetURL.startsWith(vAPI.getURL('document-blocked.html')) ) {
            const matches = /details=([^&]+)/.exec(targetURL);
            if ( matches !== null ) {
                targetURL = JSON.parse(atob(matches[1])).url;
            }
        }

        // Popup test.
        let popupType = 'popup',
            result = 0;
      
        if ( areDifferentURLs(targetURL, openerDetails.trustedURL) ) {
            result = popupMatch(openerURL, targetURL, 'popup');
        }

        // Popunder test.
        if ( result === 0 && openerDetails.popunder ) {
            result = popunderMatch(openerURL, targetURL);
            if ( result === 1 ) {
                popupType = 'popunder';
            }
        }

        if ( µb.logger.enabled ) {
            fctxt.setRealm('network').setType(popupType);
            if ( popupType === 'popup' ) {
                fctxt.setURL(targetURL)
                     .setTabId(openerTabId)
                     .setTabOriginFromURL(openerURL)
                     .setDocOriginFromURL(openerURL);
            } else {
                fctxt.setURL(openerURL)
                     .setTabId(targetTabId)
                     .setTabOriginFromURL(targetURL)
                     .setDocOriginFromURL(targetURL);
            }
            fctxt.toLogger();
        }

        // Not blocked
        if ( result !== 1 ) {
            return;
        }

        // Only if a popup was blocked do we report it in the dynamic
        // filtering pane.
        const pageStore = µb.pageStoreFromTabId(openerTabId);
        if ( pageStore ) {
            pageStore.journalAddRequest(fctxt.getHostname(), result);
            pageStore.popupBlockedCount += 1;
        }

        // Blocked
        if ( µb.userSettings.showIconBadge ) {
            µb.updateToolbarIcon(openerTabId, 0x02);
        }

        // It is a popup, block and remove the tab.
        if ( popupType === 'popup' ) {
            µb.unbindTabFromPageStats(targetTabId);
            vAPI.tabs.remove(targetTabId, false);
        } else {
            µb.unbindTabFromPageStats(openerTabId);
            vAPI.tabs.remove(openerTabId, true);
        }

        return true;
    };
})();

vAPI.tabs.registerListeners();

/******************************************************************************/
/******************************************************************************/

// Create an entry for the tab if it doesn't exist.

µBlock.bindTabToPageStats = function(tabId, context) {
    this.updateToolbarIcon(tabId, 0x03);

    // Do not create a page store for URLs which are of no interests
    if ( this.tabContextManager.exists(tabId) === false ) {
        this.unbindTabFromPageStats(tabId);
        return null;
    }

    // Reuse page store if one exists: this allows to guess if a tab is a popup
    let pageStore = this.pageStores.get(tabId);

    // Tab is not bound
    if ( pageStore === undefined ) {
        this.updateTitle(tabId);
        pageStore = this.PageStore.factory(tabId, context);
        this.pageStores.set(tabId, pageStore);
        this.pageStoresToken = Date.now();
        return pageStore;
    }


    if ( vAPI.isBehindTheSceneTabId(tabId) ) {
        return pageStore;
    }


    if ( context === 'beforeRequest' ) {
        return pageStore;
    }

    // Rebind according to context. We rebind even if the URL did not change,
    // as maybe the tab was force-reloaded, in which case the page stats must
    // be all reset.
    pageStore.reuse(context);

    this.updateTitle(tabId);
    this.pageStoresToken = Date.now();

    return pageStore;
};

/******************************************************************************/

µBlock.unbindTabFromPageStats = function(tabId) {
    //console.debug('µBlock> unbindTabFromPageStats(%d)', tabId);
    const pageStore = this.pageStores.get(tabId);
    if ( pageStore === undefined ) { return; }
    pageStore.dispose();
    this.pageStores.delete(tabId);
    this.pageStoresToken = Date.now();
};

/******************************************************************************/

µBlock.pageStoreFromTabId = function(tabId) {
    return this.pageStores.get(tabId) || null;
};

µBlock.mustPageStoreFromTabId = function(tabId) {
    return this.pageStores.get(tabId) || this.pageStores.get(vAPI.noTabId);
};

/******************************************************************************/



{
    const NoPageStore = class extends µBlock.PageStore {
        getNetFilteringSwitch(fctxt) {
            if ( fctxt.docId === 0 ) {
                const docOrigin = fctxt.getDocOrigin();
                if ( docOrigin ) {
                    return µBlock.getNetFilteringSwitch(docOrigin);
                }
            }
            return super.getNetFilteringSwitch();
        }
    };
    const pageStore = new NoPageStore(vAPI.noTabId);
    µBlock.pageStores.set(pageStore.tabId, pageStore);
    pageStore.title = vAPI.i18n('logBehindTheScene');
}

/******************************************************************************/

// Update visual of extension icon.

µBlock.updateToolbarIcon = (( ) => {
    const tabIdToDetails = new Map();

    const updateBadge = function(tabId) {
        const parts = tabIdToDetails.get(tabId);
        tabIdToDetails.delete(tabId);

        let state = 0;
        let badge = '';

        let pageStore = this.pageStoreFromTabId(tabId);
        if ( pageStore !== null ) {
            state = pageStore.getNetFilteringSwitch() ? 1 : 0;
            if (
                state === 1 &&
                this.userSettings.showIconBadge &&
                pageStore.perLoadBlockedRequestCount
            ) {
                badge = this.formatCount(pageStore.perLoadBlockedRequestCount);
            }
        }

        vAPI.setIcon(tabId, state, badge, parts);
    };

    // parts: bit 0 = icon
    //        bit 1 = badge

    return function(tabId, newParts) {
        if ( vAPI.isBehindTheSceneTabId(tabId) ) { return; }
        if ( newParts === undefined ) { newParts = 0x03; }
        let currentParts = tabIdToDetails.get(tabId);
        if ( currentParts === newParts ) { return; }
        if ( currentParts === undefined ) {
            vAPI.setTimeout(updateBadge.bind(this, tabId), 701);
        } else {
            newParts |= currentParts;
        }
        tabIdToDetails.set(tabId, newParts);
    };
})();

/******************************************************************************/

µBlock.updateTitle = (( ) => {
    const tabIdToTimer = new Map();
    const delay = 499;

    const tryAgain = function(entry) {
        if ( entry.count === 1 ) { return false; }
        entry.count -= 1;
        tabIdToTimer.set(
            entry.tabId,
            vAPI.setTimeout(( ) => { updateTitle(entry); }, delay)
        );
        return true;
    };

    const onTabReady = function(entry, tab) {
        if ( !tab ) { return; }
        const µb = µBlock;
        const pageStore = µb.pageStoreFromTabId(entry.tabId);
        if ( pageStore === null ) { return; }
        // Firefox needs this: if you detach a tab, the new tab won't have
        // its rawURL set. Concretely, this causes the logger to report an
        // entry to itself in the logger's tab selector.
        // TODO: Investigate for a fix vAPI-side.
        pageStore.rawURL = tab.url;
        µb.pageStoresToken = Date.now();
        if ( !tab.title && tryAgain(entry) ) { return; }
        // https://github.com/gorhill/uMatrix/issues/225
        // Sometimes title changes while page is loading.
        const settled = tab.title && tab.title === pageStore.title;
        pageStore.title = tab.title || tab.url || '';
        if ( !settled ) {
            tryAgain(entry);
        }
    };

    const updateTitle = function(entry) {
        tabIdToTimer.delete(entry.tabId);
        vAPI.tabs.get(entry.tabId, onTabReady.bind(null, entry));
    };

    return function(tabId) {
        if ( vAPI.isBehindTheSceneTabId(tabId) ) { return; }
        const timer = tabIdToTimer.get(tabId);
        if ( timer !== undefined ) {
            clearTimeout(timer);
        }
        tabIdToTimer.set(
            tabId,
            vAPI.setTimeout(
                updateTitle.bind(null, { tabId: tabId, count: 5 }),
                delay
            )
        );
    };
})();

/******************************************************************************/



{
    const pageStoreJanitorPeriod = 15 * 60 * 1000;
    let pageStoreJanitorSampleAt = 0;
    let pageStoreJanitorSampleSize = 10;

    const pageStoreJanitor = function() {
        const tabIds = Array.from(µBlock.pageStores.keys()).sort();
        const checkTab = tabId => {
            vAPI.tabs.get(tabId, tab => {
                if ( tab ) { return; }
                µBlock.unbindTabFromPageStats(tabId);
            });
        };
        if ( pageStoreJanitorSampleAt >= tabIds.length ) {
            pageStoreJanitorSampleAt = 0;
        }
        const n = Math.min(
            pageStoreJanitorSampleAt + pageStoreJanitorSampleSize,
            tabIds.length
        );
        for ( let i = pageStoreJanitorSampleAt; i < n; i++ ) {
            const tabId = tabIds[i];
            if ( vAPI.isBehindTheSceneTabId(tabId) ) { continue; }
            checkTab(tabId);
        }
        pageStoreJanitorSampleAt = n;

        vAPI.setTimeout(pageStoreJanitor, pageStoreJanitorPeriod);
    };

    vAPI.setTimeout(pageStoreJanitor, pageStoreJanitorPeriod);
}

/******************************************************************************/
