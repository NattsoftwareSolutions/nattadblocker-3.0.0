

(function() {
    'use strict';
    const noopfn = function() {
    };
    window.pSUPERFLY = {
        activity: noopfn,
        virtualPage: noopfn
    };
})();
