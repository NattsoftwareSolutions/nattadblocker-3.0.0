

(function() {
    'use strict';
    window.COMSCORE = {
        purge: function() {
            window._comscore = [];
        },
        beacon: function() {
        }
    };
})();
