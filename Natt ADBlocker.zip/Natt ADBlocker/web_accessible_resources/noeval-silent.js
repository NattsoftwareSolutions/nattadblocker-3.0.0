

(function() {
    'use strict';
    window.eval = new Proxy(window.eval, {          // jshint ignore: line
        apply: function() {
        }
    });
})();
