

(function() {
    'use strict';
    let result = parseInt('{{1}}', 10);
    result = isNaN(result) === false && result === 0;
    let needle = '{{2}}';
    if ( needle === '' || needle === '{{2}}' ) {
        needle = '.?';
    } else if ( /^\/.+\/$/.test(needle) ) {
        needle = needle.slice(1,-1);
    } else {
        needle = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    needle = new RegExp(needle);
    window.open = new Proxy(window.open, {
        apply: function(target, thisArg, args) {
            const url = args[0];
            if ( needle.test(url) === result ) {
                return target.apply(thisArg, args);
            }
        }
    });
})();
